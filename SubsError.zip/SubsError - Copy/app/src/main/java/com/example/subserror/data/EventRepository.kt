package com.example.subserror.data

import androidx.lifecycle.MediatorLiveData
import com.example.subserror.data.local.entity.EventEntity
import com.example.subserror.data.local.room.FavouriteDao
import com.example.subserror.data.remote.retrofit.ApiService
import com.example.subserror.utils.AppExecutors

class EventRepository private constructor(
    private val apiService: ApiService,
    private val favouriteDao: FavouriteDao,
    private val appExecutors: AppExecutors
){
    private val result = MediatorLiveData<Result<List<EventEntity>>>()
}