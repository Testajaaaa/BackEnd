package com.example.subserror.data.local.room

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.subserror.data.local.entity.EventEntity

@Dao
interface FavouriteDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertNews(event: List<EventEntity>)

    @Query("SELECT * FROM EventEntity WHERE id = :id")
    fun getFavoriteEventById(id: String): LiveData<EventEntity>
}