package com.example.subserror.ui

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.subserror.data.remote.response.EventResponse
import com.example.subserror.data.remote.response.ListEventsItem
import com.example.subserror.data.remote.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class UpcomingEventViewModel : ViewModel() {

    companion object {
        private const val TAG = "HomeViewModel"
        private const val EVENT_ID = 1
    }

    private val _daftarEvent = MutableLiveData<List<ListEventsItem>>()
    val daftarEvent: LiveData<List<ListEventsItem>> = _daftarEvent

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading


    fun getUpcomingEvent(){
        _isLoading.value = true
        val client = ApiConfig.getApiService().getEvents(EVENT_ID)
        client.enqueue(object : Callback<EventResponse> {
            override fun onResponse(call: Call<EventResponse>, response: Response<EventResponse>) {
                _isLoading.value = false
                if (response.isSuccessful) {
                    _daftarEvent.value = response.body()?.listEvents ?: emptyList()
                } else {
                    Log.e(TAG, "on Failure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<EventResponse>, t: Throwable) {
                _isLoading.value = false
                Log.e(TAG, "onFailure: ${t.message.toString()}")
            }

        })
    }

    init {
        getUpcomingEvent()
    }

}



