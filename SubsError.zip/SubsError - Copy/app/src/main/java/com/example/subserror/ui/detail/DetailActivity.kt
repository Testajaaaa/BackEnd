package com.example.subserror.ui.detail

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.HtmlCompat
import androidx.core.view.isVisible
import com.bumptech.glide.Glide
import com.example.subserror.DetailViewModel
import com.example.subserror.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding
    private val detailViewModel: DetailViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val eventId = intent.getIntExtra("EVENT_ID", -1)

        if (eventId != -1) {
            detailViewModel.getDetailEvent(eventId)
        }

        detailViewModel.eventDetail.observe(this) { event ->
            event?.let {
                binding.titleTextView.text = event.name
                binding.descriptionTextView.text = HtmlCompat.fromHtml(
                    event.description.toString(),
                    HtmlCompat.FROM_HTML_MODE_LEGACY
                )
                binding.ownerTextView2.text = event.ownerName
                val remainingQuota = (event.quota ?: 0) - (event.registrants ?: 0)
                binding.quotaTextView2.text = remainingQuota.toString()
                binding.timeTextView2.text = event.beginTime
                Glide.with(this).load(event.imageLogo).into(binding.eventImageView)

                binding.visitButton.setOnClickListener {
                    val intent = Intent(Intent.ACTION_VIEW).apply {
                        data = Uri.parse(event.link)
                    }
                    startActivity(intent)
                }
            }
        }

        detailViewModel.isLoading.observe(this) { isLoading ->
            binding.progressBar.isVisible = isLoading
        }

//        detailViewModel.errorMessage.observe(this) { errorMessage ->
//            if (errorMessage != null) {
//                binding.errorTextView.isVisible = true
//                binding.errorTextView.text = errorMessage
//            } else {
//                binding.errorTextView.isVisible = false
//            }
//        }
    }
}
