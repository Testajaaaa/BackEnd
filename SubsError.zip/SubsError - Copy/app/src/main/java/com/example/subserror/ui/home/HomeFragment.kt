package com.example.subserror.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.subserror.data.remote.response.ListEventsItem
import com.example.subserror.databinding.FragmentHomeBinding
import com.example.subserror.ui.FinishedEventViewModel
import com.example.subserror.ui.UpcomingEventViewModel

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private val upcomingEventViewModel by viewModels<UpcomingEventViewModel>()
    private val finishedEventViewModel by viewModels<FinishedEventViewModel>()


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root
        return root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val upcominglayoutManager = LinearLayoutManager(requireContext())
        _binding?.rvUpcomingEventHome?.layoutManager = upcominglayoutManager
//        val itemDecoration = DividerItemDecoration(requireContext(), layoutManager.orientation)
//        _binding?.rvEvent?.addItemDecoration(itemDecoration)

        val finishedLayoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        _binding?.rvFinishedEventHome?.layoutManager = finishedLayoutManager


        upcomingEventViewModel.daftarEvent.observe(viewLifecycleOwner) { daftarEvent ->
            setEventDataUpcoming(daftarEvent)
        }

        upcomingEventViewModel.isLoading.observe(viewLifecycleOwner){
            showLoadingUpcoming(it)
        }

        finishedEventViewModel.daftarEvent.observe(viewLifecycleOwner){
            daftarEvent -> setEventDataFinished(daftarEvent)
        }

        finishedEventViewModel.isLoading.observe(viewLifecycleOwner){
            showLoadingFinished(it)
        }

    }

    private fun setEventDataUpcoming(daftarEvent: List<ListEventsItem>) {
        val adapter = UpcomingEventAdapter()
        adapter.submitList(daftarEvent)
        _binding?.rvUpcomingEventHome?.adapter = adapter
    }

    private fun setEventDataFinished(daftarEvent: List<ListEventsItem>) {
        val adapter = FinishedEventAdapter()
        adapter.submitList(daftarEvent)
        _binding?.rvFinishedEventHome?.adapter = adapter
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun showLoadingUpcoming(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBarUpcoming.visibility = View.VISIBLE
        } else {
            binding.progressBarUpcoming.visibility = View.GONE
        }
    }

    private fun showLoadingFinished(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBarFinished.visibility = View.VISIBLE
        } else {
            binding.progressBarFinished.visibility = View.GONE
        }
    }

}