package com.example.subserror.ui.finished

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.GridLayoutManager
import com.example.subserror.data.response.ListEventsItem
import com.example.subserror.databinding.FragmentNotificationsBinding
import com.example.subserror.ui.FinishedEventViewModel

class FinishedFragment : Fragment() {

    private var _binding: FragmentNotificationsBinding? = null
    private val binding get() = _binding!!

    private val finishedEventViewModel by viewModels<FinishedEventViewModel>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentNotificationsBinding.inflate(inflater, container, false)
        val root: View = binding.root
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val layoutManager = GridLayoutManager(requireContext(), 2)
        _binding?.rvFinishedEvent?.layoutManager = layoutManager


        finishedEventViewModel.daftarEvent.observe(viewLifecycleOwner){
            daftarEvent -> setEventData(daftarEvent)
        }

        finishedEventViewModel.isLoading.observe(viewLifecycleOwner){
            showLoading(it)
        }
    }

    private fun setEventData(daftarEvent: List<ListEventsItem>) {
        val adapter = FinEventAdapter()
        adapter.submitList(daftarEvent)
        _binding?.rvFinishedEvent?.adapter = adapter
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }
}